<!-- View for /home/discover route -->


<?php $__env->startSection('content'); ?>


    <?php if(session('status')): ?>
            <?php echo e(session('status')); ?>

    <?php endif; ?>

    <div>
        <nav id="navbar-example2" class="navbar sticky-top navbar-dark bg-dark" style="margin-top:-25px" >
            <a class="navbar-brand" href="#">Categories</a>
            <ul class="nav nav-pills" id="discover-nav"></ul>
        </nav>

        <!-- <div class="row no-gutters justify-content-center" style="color:white">
            <div class="form-check col-4 col-sm-2 col-md-1">
                <input class="form-check-input" type="radio" name="searchParam"value="title" checked>
                <label class="form-check-label" for="searchTitle">
                    Title
                </label>
            </div>
            <div class="form-check col-4 col-sm-2 col-md1">
                <input class="form-check-input" type="radio" name="searchParam" value="author">
                <label class="form-check-label" for="searchAuthor">
                    Author
                </label>
            </div>
                <div class="form-check col-4 col-sm-2 col-md-1">
                <input class="form-check-input" type="radio" name="searchParam" value="subject">
                <label class="form-check-label" for="searchSubject">
                    Subject
                </label>
            </div>
            <div class="input-group search-area">
                <input class="col-8 col-lg-4" type="text" id="searchBox">
                <button class="col-2 col-lg-1" id="searchButton">Search</button>
            </div>
        </div> -->

        <div id="searchResults"></div>

        <!-- Modal -->
        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Add Book</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="/book">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group">
                                <input type="text" class="form-control" name="title" id="title" aria-describedby="emailHelp" required>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="author" id="author" placeholder="Book Author">
                            </div>
                            <div class="form-group">
                                <label for="date_completed">Date Completed</label>
                                <input type="date" class="form-control" name="date_completed" id="date_completed">
                            </div>
                            <div class="form-group">
                                <label for="rating">Book Rating</label>
                                <select name="rating" type="select" class="form-control" id="rating">   
                                    <option value="5">5</option>
                                    <option value="4">4</option>
                                    <option value="3">3</option>
                                    <option value="2">2</option>
                                    <option value="1">1</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="list_id">Select a book list</label>
                                <select name="list_id" class="form-control" type="select" required>
                                    <?php $__currentLoopData = $booklists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booklist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($booklist->id); ?>"><?php echo e($booklist->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-success">Add Book</button>
                            <?php if(session('status')): ?>
                            <div class="alert alert-warning" role="alert">
                            <?php echo e(session('status')); ?>

                            </div>
                            <?php endif; ?>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <div data-spy="scroll" data-target="#navbar-example2" data-offset="0" id="row-container"></div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.console', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\conno\Desktop\github\booj-reading-list\resources\views/discover.blade.php ENDPATH**/ ?>