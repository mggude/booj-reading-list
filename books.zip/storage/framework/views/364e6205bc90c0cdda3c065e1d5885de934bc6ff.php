<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/home.css')); ?>" />
    
    <style>
        .bk-nav-item{
            margin: 7px 0 0 7px;
        }

        .home-console {
            margin-top: -25px;
        }

        .list-nav {
            background-color: #ff000059;
            min-height: 95vh;
        }

        #col-left {
            border-right: 1px solid lightgray;
        }

        #col-right{
            border-left: 1px solid lightgray;
        }

        </style>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'boojreadinglist.xyz')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('home')); ?>">
                                        Home
                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('discover')); ?>">
                                        Discover
                                    </a>
                                    
                                    
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="row no-gutters justify-content-center">

            <!-- Side navigation for users book lists -->
            <div class="col-6 col-sm-3 col-md-2 text-dark bg-light list-nav order-2 order-sm-1" style="min-height:95vh" id="col-left">
                <a href="/home">
                            <h5 class="bk-nav-item text-dark"> Make List +</h5><br>
                        </a>
                        <h5 class="bk-nav-item" style="text-decoration:underline">My booklists</h5>
                <?php $__currentLoopData = $booklists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booklist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/booklist/<?php echo e($booklist->id); ?>">
                        <h5 class="bk-nav-item text-dark list-nav-item"> <?php echo e($booklist->title); ?></h5><br>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Main UI for interacting with book lists/books/profiles/discover -->
            <div class="col-9 col-md-8 order-1 order-sm-2" style="">
                <main class="py-4">
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            </div>

            <!-- Side bar for connecting with other users -->
            <div class="col-6 col-md-2 bg-light order-3" id="col-right">
                <h5 class="bk-nav-item">See what others are reading</h5>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/profile/<?php echo e($user->id); ?>">
                        <h5 class="bk-nav-item"><?php echo e($user->name); ?></h5><br>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>    
    </div>
</body>
</html>
<?php /**PATH C:\Users\conno\Desktop\github\booj-reading-list\resources\views/layouts/app.blade.php ENDPATH**/ ?>