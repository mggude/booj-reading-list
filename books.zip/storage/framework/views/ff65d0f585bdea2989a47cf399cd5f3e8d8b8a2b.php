<?php $__env->startSection('content'); ?>
<div class="row no-gutters justify-content-center">

        <!-- Side navigation for users book lists -->
        <div class="col-3">
            <?php $__currentLoopData = $booklists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booklist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/booklist/<?php echo e($booklist->id); ?>">
                    <h5><?php echo e($booklist->title); ?></h5><br>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Main UI for interacting with book lists -->
        <div class="col-md-6">
                <h1>Console</h1>
                <?php echo $__env->yieldContent('booklist'); ?>
                <?php echo $__env->yieldContent('home'); ?>
        </div>

        <!-- Side bar for connecting with other users -->
        <div class="col-3">
            <?php $__currentLoopData = $booklists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booklist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/booklist/<?php echo e($booklist->id); ?>">
                    <h5><?php echo e($booklist->title); ?></h5><br>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    
    
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\conno\Desktop\github\booj-reading-list\resources\views/nested/console.blade.php ENDPATH**/ ?>