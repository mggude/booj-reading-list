<?php $__env->startSection('content'); ?>
<div class="row no-gutters justify-content-center">
        <!-- Book card -->
        <div class="col- 10 col-sm-8 col-md-6">
            <div class="card mb-3" style="max-width: 540px;">

        <a href="/home">Go Home</a>
        <div class="col-md-8">
    
                <h2><?php echo e($profile->name); ?></h2>
        </div>
        <br>
        <strong><?php echo e($profile->name); ?>'s Book List's</strong>
    <div class="accordion" id="accordionExample">

        <?php $__currentLoopData = $booklists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booklist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="card-header" id="headingOne">
                    <h2 class="mb-0">
                        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse<?php echo e($booklist->id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($booklist->id); ?>">
                        <?php echo e($booklist->title); ?>

                        </button>
                    </h2>
                </div>
            <!-- Book list headers -->
                <div id="collapse<?php echo e($booklist->id); ?>" class="collapse" aria-labelledby="heading<?php echo e($booklist->id); ?>" data-parent="#accordionExample">
                    <div class="card-body">
                        <div class="row no-gutters list-row" style="margin-bottom:15px">
                            <strong class="col-5 col-sm-3">Title</strong>
                            <strong class="col-5 col-sm-3">Author</strong>
                        </div>
                        <!-- Rendering the book data -->
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row no-gutters list-row bg-light">
                                <p class="col-5 col-sm-3"><a href="/book/<?php echo e($book->id); ?>" class=""><?php echo e($book -> title); ?></a></p>
                                <p class="col-5 col-sm-3"><?php echo e($book -> author); ?></p>
                                </div>
                            <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>  
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\conno\Desktop\github\booj-reading-list\resources\views/profile.blade.php ENDPATH**/ ?>