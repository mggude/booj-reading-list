# Booj Reading List
#### Discover, Read, Be Origional

[boojreadinglist.xyz](http://boojreadinglist.xyz)

**booj reading list app... probably the best reading list app ever**

Built with a Laravel framework and hosted on an AWS EC2 instance.